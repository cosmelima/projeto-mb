import { PropostasPrintComponent } from './propostas-print.component';
import { PropostasRascunhoPrintComponent } from './propostas-rascunho-print.component';

@NgModule({
  declarations: [
    PropostasComponent,
    PropostasPrintComponent,
    PropostasRascunhoPrintComponent
  ],
})
export class PropostasModule { } 