import { Component } from '@angular/core';

@Component({
  selector: 'app-modulo-form',
  templateUrl: './modulo-form.component.html',
  styleUrls: ['./modulo-form.component.scss']
})
export class ModuloFormComponent {} 